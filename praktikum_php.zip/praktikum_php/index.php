<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <title>Data Karyawan</title>
</head>
<body>
  <h2>Daftar Karyawan Perusahaan</h2>
  <a href="form_tambah.html">Tambah Karyawan Baru</a>
  <br><br>

  <table border="1" cellpadding="5" cellspacing="0">
    <thead>
      <tr>
        <th>ID</th>
        <th>Nama Lengkap</th>
        <th>Jabatan</th>
        <th>Email</th>
        <th>Aksi</th>
      </tr>
    </thead>
    <tbody>
      <?php
        include 'koneksi.php'; // Menyertakan file koneksi

        $sql = "SELECT id, nama, jabatan, email FROM karyawan";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
          // Loop untuk menampilkan setiap baris data
          while ($row = $result->fetch_assoc()) {
            echo "<tr>";
            echo "<td>" . $row["id"] . "</td>";
            echo "<td>" . $row["nama"] . "</td>";
            echo "<td>" . $row["jabatan"] . "</td>";
            echo "<td>" . $row["email"] . "</td>";
            echo "<td>
                    <a href='form_edit.php?id=" . $row["id"] . "'>Edit</a> |
                    <a href='hapus.php?id=" . $row["id"] . "' onclick='return confirm(\"Apakah Anda yakin ingin menghapus data ini?\")'>Hapus</a>
                  </td>";
            echo "</tr>";
          }
        } else {
          echo "<tr><td colspan='5'>Tidak ada data</td></tr>";
        }

        $conn->close();
      ?>
    </tbody>
  </table>
</body>
</html>
