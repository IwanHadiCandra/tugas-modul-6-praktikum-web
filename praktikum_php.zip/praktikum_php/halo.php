<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <title>Tes PHP</title>
</head>
<body>
  <h1>
    <?php echo "Halo dari Server PHP!"; ?>
  </h1>
  <p>
    Jika Anda melihat teks ini, artinya server PHP Anda berjalan dengan baik.
  </p>
</body>
</html>
